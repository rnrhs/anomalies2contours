User Block
	Plugin Initialization
	Raster Selection
	Histogram Generation with Update Button
	Sensitivity Adjustment
Raster Block
	Raster, Band Reading
	Mask Creation Based on the Low and High Threshold
	Raster File Generation
Vector Block
	Polygonization with Apply Button
	Vector File Generation
	Statistical Data Filling
	Cleaning and Sorting Data
